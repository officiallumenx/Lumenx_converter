import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import {
  Outlet,
  createRootRouteWithContext,
  useRouter,
  HeadContent,
  Scripts,
  Link,
} from "@tanstack/react-router";

import appCss from "../styles.css?url";
import { Button, TypographyProvider } from "@lumenx/ui";
import { SITE_NAME } from "@/content/nav";
import { SITE_MOTION_BOOT } from "@/motion/boot";
import { SiteShell } from "@/components/SiteShell";

function NotFoundComponent() {
  return (
    <SiteShell>
      <div className="flex min-h-[60vh] items-center justify-center px-4">
        <div className="max-w-md text-center">
          <p className="site-kicker">Not found</p>
          <h1 className="site-section-title mt-3">This page isn’t on the LumenX website.</h1>
          <p className="mt-3 text-muted-foreground">
            The link may be old. Products, pricing, and downloads are in the menu.
          </p>
          <Button asChild className="mt-6 font-semibold">
            <Link to="/">Back home</Link>
          </Button>
        </div>
      </div>
    </SiteShell>
  );
}

function ErrorComponent({ error, reset }: { error: Error; reset: () => void }) {
  const router = useRouter();
  console.error(error);
  return (
    <SiteShell>
      <div className="flex min-h-[60vh] items-center justify-center px-4">
        <div className="max-w-md text-center">
          <h1 className="site-section-title">Something went wrong</h1>
          <p className="mt-2 text-sm text-muted-foreground">
            This page could not be loaded. Try again, or come back from the home page.
          </p>
          <Button
            type="button"
            className="mt-6 font-semibold"
            onClick={() => {
              router.invalidate();
              reset();
            }}
          >
            Try again
          </Button>
        </div>
      </div>
    </SiteShell>
  );
}

export const Route = createRootRouteWithContext<{ queryClient: QueryClient }>()({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1" },
      { name: "theme-color", content: "#3B5CD9" },
      { name: "application-name", content: SITE_NAME },
    ],
    links: [
      { rel: "stylesheet", href: appCss },
      // Google Search uses one crawlable square favicon from the homepage (≥48px recommended).
      { rel: "icon", href: "/favicon.png", type: "image/png", sizes: "192x192" },
      { rel: "icon", href: "/favicon-48.png", type: "image/png", sizes: "48x48" },
      { rel: "shortcut icon", href: "/favicon.png", type: "image/png" },
      { rel: "apple-touch-icon", href: "/apple-touch-icon.png", sizes: "180x180" },
      { rel: "preconnect", href: "https://fonts.googleapis.com" },
      { rel: "preconnect", href: "https://fonts.gstatic.com", crossOrigin: "" },
      {
        rel: "stylesheet",
        href: "https://fonts.googleapis.com/css2?family=DM+Sans:opsz,wght@9..40,400;9..40,600&family=JetBrains+Mono:wght@400&display=swap",
      },
    ],
  }),
  shellComponent: RootShell,
  component: RootComponent,
  notFoundComponent: NotFoundComponent,
  errorComponent: ErrorComponent,
});

function RootShell({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" data-app="website">
      <head>
        <HeadContent />
      </head>
      <body>
        {children}
        <script dangerouslySetInnerHTML={{ __html: SITE_MOTION_BOOT }} />
        <Scripts />
      </body>
    </html>
  );
}

function RootComponent() {
  const { queryClient } = Route.useRouteContext();
  return (
    <QueryClientProvider client={queryClient}>
      <TypographyProvider>
        <Outlet />
      </TypographyProvider>
    </QueryClientProvider>
  );
}
