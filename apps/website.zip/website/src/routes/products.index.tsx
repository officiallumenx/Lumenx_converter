import { createFileRoute, redirect } from "@tanstack/react-router";

export const Route = createFileRoute("/products/")({
  beforeLoad: () => {
    throw redirect({ to: "/platform" });
  },
  component: function ProductsIndexRedirect() {
    return null;
  },
});
