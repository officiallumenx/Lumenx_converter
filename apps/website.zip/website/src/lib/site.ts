/** Public origin for canonical URLs, Open Graph, and the sitemap. */

type OriginReader = () => string | undefined;

let requestOriginReader: OriginReader | undefined;

/** Wired from the Worker entry so SSR `head()` can see this request’s origin. */
export function registerRequestOriginReader(reader: OriginReader): void {
  requestOriginReader = reader;
}

function peekStartRequest(): Request | undefined {
  try {
    const key = Symbol.for("tanstack-start:event-storage");
    const storage = (globalThis as unknown as Record<symbol, { getStore?: () => { h3Event?: { req?: Request } } }>)[key];
    return storage?.getStore?.()?.h3Event?.req;
  } catch {
    return undefined;
  }
}

const PRODUCTION_SITE_ORIGIN = "https://lumenxtech.in";

export function getSiteOrigin(request?: Request): string {
  const fromEnv = import.meta.env.VITE_SITE_ORIGIN?.trim().replace(/\/$/, "") ?? "";
  if (fromEnv) return fromEnv;
  // Stable canonical host for production builds even when CF build vars omit VITE_SITE_ORIGIN.
  if (import.meta.env.PROD) return PRODUCTION_SITE_ORIGIN;
  const incoming = request ?? peekStartRequest();
  if (incoming) {
    try {
      return new URL(incoming.url).origin;
    } catch {
      /* ignore */
    }
  }
  const fromRequest = requestOriginReader?.()?.replace(/\/$/, "") ?? "";
  if (fromRequest) return fromRequest;
  if (typeof window !== "undefined" && window.location?.origin) {
    return window.location.origin;
  }
  return "";
}

export function canonicalUrl(path: string, request?: Request): string | undefined {
  const origin = getSiteOrigin(request);
  if (!origin) return undefined;
  const normalized = path.startsWith("/") ? path : `/${path}`;
  if (normalized === "/") return `${origin}/`;
  return `${origin}${normalized.replace(/\/$/, "")}`;
}

/** Public marketing hosts that must stay crawlable even if VITE_NOINDEX is set in CI. */
export function isProductionMarketingHost(hostname: string): boolean {
  const host = hostname.trim().toLowerCase().replace(/\.$/, "");
  return host === "lumenxtech.in" || host === "www.lumenxtech.in";
}

export function isNoIndex(request?: Request): boolean {
  // Production marketing builds must stay crawlable even if CF sets VITE_NOINDEX=true.
  if (import.meta.env.PROD) {
    const configured = import.meta.env.VITE_SITE_ORIGIN?.trim() ?? "";
    if (!configured) return false; // defaults to lumenxtech.in via getSiteOrigin()
    try {
      if (isProductionMarketingHost(new URL(configured).hostname)) return false;
    } catch {
      /* fall through and honor the flag for non-URL values */
    }
  }

  const incoming = request ?? peekStartRequest();
  if (incoming) {
    try {
      if (isProductionMarketingHost(new URL(incoming.url).hostname)) return false;
    } catch {
      /* ignore */
    }
  }
  const fromRequest = requestOriginReader?.() ?? "";
  if (fromRequest) {
    try {
      if (isProductionMarketingHost(new URL(fromRequest).hostname)) return false;
    } catch {
      /* ignore */
    }
  }

  const flag = import.meta.env.VITE_NOINDEX?.trim().toLowerCase();
  return flag === "1" || flag === "true" || flag === "yes";
}

export const SITE_PATHS = [
  "/",
  "/platform",
  "/platform/admin",
  "/platform/connect",
  "/platform/transport",
  "/platform/admissions",
  "/platform/careers",
  "/solutions",
  "/modules",
  "/pricing",
  "/resources",
  "/resources/help",
  "/resources/faq",
  "/resources/downloads",
  "/about",
  "/contact",
  "/get-started",
  "/login",
  "/privacy",
  "/terms",
  "/cookies",
  "/data-request",
] as const;
